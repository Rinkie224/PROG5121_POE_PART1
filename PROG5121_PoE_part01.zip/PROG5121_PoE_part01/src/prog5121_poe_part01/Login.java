/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prog5121_poe_part01;
import java.util.regex.Pattern;

/**
 *
 * @author Student
 */
public class Login {
     private String username;
    private String password;
    private String cellPhoneNumber;
    private String firstName;
    private String lastName;
    
//check if username contains _ and is <=5 characters
 public boolean 
        checkUserName(String username){
        return username.contains("_") && username.length()<=5;
    }
//check password criteria
  public boolean
        checkPasswordComplexity(String password){
        if (password.length()<8) return false;
        
        boolean hasCapital= false;
        boolean hasNumber= false;
        boolean hasSpecial= false;
        
        for (char ch: password.toCharArray()){
            if (Character.isUpperCase(ch)) hasCapital= true;
            else if (Character.isDigit(ch)) hasNumber= true;
            else if (!Character.isLetterOrDigit(ch)) hasSpecial= true;
        }
        return hasCapital && hasNumber && hasSpecial;
        }
//check SA international cell phone number format (+27 followed by 9 digits)
//Reference: Regular expression syntax adapted from java Pattern
    public boolean
        checkCellPhoneNumber(String cellPhoneNumber){
        String regex= "^\\+27\\d{9}$";
        return Pattern.matches(regex,cellPhoneNumber);
        }
//Registers user and returns system status message
    public String registerUser(String username, String password, String cellPhoneNumber, String firstName, String lastName){
        if (!checkUserName(username)){
            return "Username is not correctly formated,please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity(password)){
            return "Password is not correctly formattd; please ensure that your password contains at least eight characters,a capital letter,a number,and a special charactr.";
         }
        if (!checkCellPhoneNumber(cellPhoneNumber)){
            return "cell phne number is incorrectly formatted or does not contain international country code.";
         }
        this.username= username;
        this.password= password;
        this.cellPhoneNumber= cellPhoneNumber;
        this.firstName= firstName;
        this.lastName= lastName;
        
        return "User successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";
    }
//Verifies stored information against entered login details
    public boolean loginUser(String enteredUsername,String enteredPassword){
        if (this.username== null || this.password== null) return false;
          return this.username.equals(enteredUsername) && this.password.equals(enteredPassword);
      }
//Returns formatted login confirm or error message
     public String returnLoginStatus(boolean isLoggedIn){
          if(isLoggedIn){
              return "Login successful";
          }else{
              return "Username or password incorrect,please try again.";
          }
     }
}
        
    


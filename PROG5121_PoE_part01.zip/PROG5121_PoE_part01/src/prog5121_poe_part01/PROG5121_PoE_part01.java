/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prog5121_poe_part01;
import java.util.Scanner;

/**
 *
 * @author Student
 */
public class PROG5121_PoE_part01 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    Scanner scanner= new Scanner(System.in);
    Login userLogin= new Login();
    
    System.out.println("=== USER REGISTRATION ===");
    
    System.out.println("Enter your First Name:");
    String firstName= scanner.nextLine();
    System.out.println("Enter your Last Name:");
    String lastName= scanner.nextLine();
    System.out.println("Enter Username (max 5 chars,must contain '_'):");
    String username= scanner.nextLine();
    System.out.println("Enter Password (min 8 chars,1 upper,1 number,1 special):");
    String password= scanner.nextLine();
    System.out.println("Enter SA Cell Phone Number (e.g. +27848865981):");
    String cellNumber= scanner.nextLine();
    
    //Attempt Registration
    String regStatus= userLogin.registerUser(username,password,cellNumber,firstName, lastName);
    System.out.println("\n" + regStatus);
    
    //Stop program if registration fails based on message content
    if (!regStatus.contains("successfully")){
        System.out.println("\nRegistration failed.Please restart and try again.");
        scanner.close();
        return;        
    }
    System.out.println("\n=== USER LOGIN ===");
    
    System.out.println("Enter Username: ");
    String loginUsername= scanner.nextLine();
    System.out.println("Enter Password: ");
    String loginPassword= scanner.nextLine();
    
    //Attempt login
     boolean isAuthenticated= userLogin.loginUser(loginUsername, loginPassword);
     String loginStatusMessage= userLogin.returnLoginStatus(isAuthenticated);
     
    System.out.println("\n" + loginStatusMessage);
    
    scanner.close();
    
    }
    
}

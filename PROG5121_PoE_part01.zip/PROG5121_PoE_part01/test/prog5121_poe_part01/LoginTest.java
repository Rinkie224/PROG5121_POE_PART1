/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package prog5121_poe_part01;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Student
 */
public class LoginTest {
    
    private final Login login= new Login();
    
    @Test
    public void testUsernameCorrectlyFormatted(){
    assertTrue(login.checkUserName("hop_1"));
    }
    
    @Test
    public void testUsernameInCorrectlyFormatted(){
    assertFalse(login.checkUserName("hope!!1"));
    }
    
    @Test
   public void testPasswordMeetsComplexity(){
    assertTrue(login.checkPasswordComplexity("Te&&tso@pe77!"));
    }
    
    @Test
     public void testPasswordDoesNotMeetsComplexity(){
     assertFalse(login.checkPasswordComplexity("password"));
    }
     
    @Test
     public void testCellPhoneNumberCorrectlyFormatted(){
     assertTrue(login.checkCellPhoneNumber("+27848865981"));
    }
    
     @Test
     public void testCellPhoneNumberInCorrectlyFormatted(){
     assertFalse(login.checkCellPhoneNumber("0839557217"));
    }
    @Test
    public void testLoginStatus() {
    login.registerUser("hop_1","Te&&tso@pe77!","+27848865981", "Hope" ,"Tebatso");
    assertTrue(login.loginUser("hop_1","Te&&tso@pe77!"));
    }
    @Test
    public void testLoginFailed() {
    login.registerUser("hop_1","Te&&tso@pe77!","+27848865981", "Hope" ,"Tebatso");
    assertFalse(login.loginUser("hop_1","wrongPassword"));
    }
}